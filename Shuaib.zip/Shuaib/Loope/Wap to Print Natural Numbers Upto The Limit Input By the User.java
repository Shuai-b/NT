//To print Natural Numbers Upto The Limit Input By the user 
import java.io.*;
import java.util.*;
class s 
{ 	int n ;
	Scanner br = new Scanner (System.in);
	public static void main (String args []) 
	{
		s obj = new s () ;
		obj.display() ;
		
	}//End Of main 
	void display () 
	{  
		System.out.println("Enter a Number "); 
			n=br.nextInt() ;
		for (int i =1 ; i<=n;i++) 
			System.out.println(i);
	}//End Of display()
}//End Of class 
/*
 *Output:
 *Enter a Number 
6
1
2
3
4
5
6*/