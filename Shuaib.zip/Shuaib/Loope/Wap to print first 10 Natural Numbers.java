//To Print First 10 Natural Numbers
import java.io.*;
import java.util.*;
class s 
{
	public static void main (String args []) 
	{
		s obj = new s () ;
		obj.display() ;
		
	}//End Of main 
	void display () 
	{
		for (int i =1 ; i<=10;i++) 
			System.out.println(i);
	}//End Of display()
}//End Of class 
/* output: 
 *1
  2
  3 
  4
  5
  6
  7
  8
  9
  10
