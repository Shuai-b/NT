import java.io.*;
import java.util.*;
class s 
{ 
	int sum = 0 ;
	public static void main (String args []) 
	{
		s obj = new s () ;
		obj.display() ;
		
	}//End Of main 
	void display () 
	{
		for (int i =1 ; i<=10;i++) 
			sum=sum+i;
			System.out.println("Sum Of the Digits = "+sum);
	}//End Of display()
}//End Of Class 
/*Output :
 */