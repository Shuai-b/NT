/**
 * @(#)lcm.java
 *
 *
 * @author 
 * @version 1.00 2017/7/25
 */


public class lcm {

    public lcm() {
    }
    
    
}