/**
 * @(#)Text1.java
 *
 *
 * @author 
 * @version 1.00 2017/7/4
 */


public class Text1 {

    public Text1() {
    }
    
    
}